# Worksheet task



Even for this relatively small task the best approach is to develop the solution slowly.

The code template suggests the steps to produce the solution.



Compile your code frequently to check for syntax errors.



Test your executable code with a range of cases that you can compute by hand.

The worksheet description has some suggestions.

