
def main():
    print('Hello')

