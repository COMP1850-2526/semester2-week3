
/*
 * Hello world program
 * - compilation errors
 */

int main( void ) {
    
    printf("Hello\n");

    return 0;    
}	

