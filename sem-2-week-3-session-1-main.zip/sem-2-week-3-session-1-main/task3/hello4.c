
/*
 * Hello world program
 * - compilation errors?
 */

#include <stdio.h>

int main( void ) 
{ printf("Hello\n");
return 0; }	

